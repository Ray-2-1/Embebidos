# FirebaseAuthKotlinApp

Proyecto Android mínimo en Kotlin que implementa registro e inicio de sesión con Firebase Authentication (Email/Password).

## Qué incluye
- Actividades: MainActivity (login), RegisterActivity (registro), HomeActivity (pantalla principal).
- Dependencias configuradas en `app/build.gradle.kts` (Firebase Auth vía BoM).
- Layouts simples en XML.
- Archivo de ejemplo `app/google-services.json` (debe reemplazarse).

## Pasos para configurar (obligatorio)
1. Crea un proyecto en Firebase Console: https://console.firebase.google.com/
2. Añade una aplicación Android con el paquete `com.example.firebaseauth`.
   - Registra el SHA-1 si planeas usar login social o Google Sign-In.
3. Descarga el archivo `google-services.json` proporcionado por Firebase y reemplaza `app/google-services.json`.
4. Habilita **Authentication -> Sign-in method -> Email/Password** en Firebase Console.
5. Abre el proyecto en Android Studio (File -> Open -> la carpeta `FirebaseAuthKotlinApp`).
6. Si Android Studio te pide sincronizar Gradle, acepta. Asegúrate de tener el plugin Google Services añadido en el gradle wrapper / plugins.
7. Ejecuta la app en un emulador o dispositivo.

## Nota sobre .rar
En este entorno he generado un archivo ZIP que contiene el proyecto. Si necesita un archivo .rar, puede convertirlo localmente usando WinRAR o herramientas similares.

