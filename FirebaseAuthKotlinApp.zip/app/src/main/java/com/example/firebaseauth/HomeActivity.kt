package com.example.firebaseauth

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth

class HomeActivity : AppCompatActivity() {
    private lateinit var auth: FirebaseAuth
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        auth = FirebaseAuth.getInstance()
        val user = auth.currentUser
        val welcome = findViewById<TextView>(R.id.welcomeText)
        welcome.text = "Bienvenido: ${'$'}{user?.email}"

        val logoutBtn = findViewById<Button>(R.id.logoutButton)
        logoutBtn.setOnClickListener {
            auth.signOut()
            finish()
        }
    }
}
