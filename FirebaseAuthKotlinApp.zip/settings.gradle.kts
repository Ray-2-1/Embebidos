rootProject.name = "FirebaseAuthKotlinApp"
include(":app")
